# 組織学カード（Android）

講義スライドから作った一問一答を解くAndroidアプリです。中身はWebViewで動くHTMLアプリで、オフラインで使えます。

- 内蔵デッキ：組織学 1–3（総論・結合組織・軟骨・骨・脂肪・血液／骨髄）229問（画像問題48問）
- Claudeに作ってもらったデッキファイル（.json）を読み込んで、問題をいくらでも追加できます
- 「覚えた／もう一度」の記録、追加デッキは端末内に保存されます
- 記録はiPhone版（Webアプリ版）と自動で同期できます（v1.1〜）

---

## 1. APKを作る（GitHubで自動ビルド。PCにソフトを入れる必要はありません）

1. GitHub（https://github.com）でアカウントを作り、右上の「＋」→「New repository」
   - 名前は何でもよい（例：histo-flash）
   - **Private（非公開）を選ぶ**（講義スライドの画像を含むため）
2. 作ったリポジトリの画面で「uploading an existing file」を押し、このフォルダの中身を**すべて**ドラッグして「Commit changes」
   - `.github` フォルダ（ドットで始まる隠しフォルダ）も必ず含めること。Macでは Finder で `Command + Shift + .` を押すと表示されます
3. 上部の「Actions」タブを開く。「Build APK」が自動で動きます（5分前後）
   - 動いていなければ「Build APK」→「Run workflow」
   - 「Actions」に何も出ないときは `.github` が上がっていません。「Add file」→「Create new file」でファイル名に `.github/workflows/build-apk.yml` と入力し、同名ファイルの中身を貼り付けて保存してください
4. 緑のチェックが付いたら、その実行を開き、下の「Artifacts」から **HistoFlash-apk** をダウンロード（zip）→ 展開すると `HistoFlash.apk`
5. APKをスマホに移してタップ → 「提供元不明のアプリ」のインストールを許可 → インストール

### Android Studioを使う場合
このフォルダを「Open」で開き、同期後に メニュー「Build」→「Build App Bundle(s) / APK(s)」→「Build APK(s)」。

### アップデートについて
v1.0から更新するときは、GitHubのリポジトリで `app/src/main/assets/www/index.html`・`app/src/main/AndroidManifest.xml`・`app/build.gradle` を新しいものに差し替えます（「Add file」→「Upload files」で同じ場所に上書き）。Actionsが自動でビルドし直します。

毎回同じ署名鍵（`app/histoflash.keystore`）で署名するので、新しいAPKを上書きインストールしても記録と追加デッキは残ります。
**アプリを一度削除すると消える**ので、機種変更などの前に「管理」→「バックアップ」→「書き出す」で保存してください。

---

## 2. 新しい講義のカードを追加する

1. アプリの「管理」→「依頼文をコピー」
2. Claude（claude.ai やアプリ）の新しいチャットに、講義スライド（PDF）を添付し、コピーした依頼文を貼り付けて送信
3. Claudeが出力した `○○.json` を端末に保存
4. アプリの「管理」→「ファイルから追加」で選ぶ

- 既存デッキに問題を足す・直すとき：そのデッキを「管理」→「書き出す」で保存し、スライドと一緒に添付して「このデッキに追加して」と頼む。デッキIDとカードIDが同じなら、読み込み時に上書き更新され、「覚えた」記録も残ります
- 読み込みに失敗したときは、表示されたエラー文をそのままClaudeに伝えれば直してもらえます
- ファイルが保存しにくいときは、JSONをコピーして「貼り付けて追加」でも読み込めます（画像が多いと重くなります）

---

## 端末間の同期（Android版とiPhone版）

「覚えた／もう一度」の記録を、Google Apps Scriptで作る自分専用の同期サーバー経由で自動的にそろえられます。
設定方法は `同期の設定.md`（Code.gs と一緒に配布）を見てください。アプリ側は「管理」→「端末間の同期」にURLと合言葉を入れるだけです。

---

## 3. デッキファイルの形式（histo-flash-deck v1）

```json
{
  "format": "histo-flash-deck",
  "version": 1,
  "id": "histology-04",
  "title": "組織学 4 上皮組織",
  "subject": "組織学",
  "sections": [{"id": "ep", "name": "上皮"}],
  "images": {"ep_simple": "data:image/jpeg;base64,..."},
  "cards": [
    {"id": "ep-001", "s": "ep", "q": "問題", "a": "答え（改行は \\n）",
     "n": "補足メモ（任意）", "en": "英語の用語（任意）", "extra": false,
     "img": "問題の画像キー（任意）", "aimg": "答えの画像キー（任意）"}
  ]
}
```

| 項目 | 内容 |
|---|---|
| id | デッキID。半角英数字と `- _ .`。同じIDを読み込むと上書き更新 |
| sections | 範囲の分類（アプリ上部のボタンになる） |
| images | 画像。キー → data URI（JPEG/PNG/WebP） |
| cards[].id | カードID。更新しても変えないこと（記録の引き継ぎに使う） |
| cards[].extra | true でスライド外の「補足」扱い（「スライド範囲のみ」で除外できる） |

---

## 4. ファイル構成

```
app/src/main/assets/www/index.html   アプリ本体（HTML/CSS/JS）
app/src/main/assets/www/builtin.js   内蔵デッキ（組織学 1–3）
app/src/main/java/.../MainActivity.java  WebView、ファイル読み込み・保存、戻るボタン
.github/workflows/build-apk.yml      GitHubでAPKを作る設定
```

内蔵デッキを差し替える・増やすときは `builtin.js` の `window.BUILTIN_DECKS` 配列にデッキを入れてビルドし直します。
